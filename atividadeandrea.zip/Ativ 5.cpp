#include <stdio.h>

int main() {
   int a, b, temp;

   printf("Informe o valor de a: ");
   scanf("%d", &a);

   printf("Informe o valor de b: ");
   scanf("%d", &b);

   temp = a;
   a = b;
   b = temp;

   printf("O novo valor de a e: %d\n", a);
   printf("O novo valor de b e: %d\n", b);

   return 0;
}

