#include <stdio.h>

int main() {
   int anoNasc, anoAtual, idade, idadeEm2012;

   printf("Informe o ano de nascimento: ");
   scanf("%d", &anoNasc);

   printf("Informe o ano atual: ");
   scanf("%d", &anoAtual);

   idade = anoAtual - anoNasc;
   idadeEm2012 = 2012 - anoNasc;

   printf("Idade atual: %d anos\n", idade);
   printf("Idade em 2012: %d anos\n", idadeEm2012);

   return 0;
}

