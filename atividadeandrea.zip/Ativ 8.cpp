#include <stdio.h>

int main()
{
    float numHoras, salarioMinimo, salarioBruto, imposto, salarioLiquido, valorHoraTrabalhada;

    printf("Digite o numero de horas trabalhadas: ");
    scanf("%f", &numHoras);

    printf("Digite o valor do salario minimo: ");
    scanf("%f", &salarioMinimo);

    valorHoraTrabalhada = salarioMinimo / 2;
    salarioBruto = numHoras * valorHoraTrabalhada;
    imposto = salarioBruto * 0.03;
    salarioLiquido = salarioBruto - imposto;

    printf("Valor da hora trabalhada: R$ %.2f\n", valorHoraTrabalhada);
    printf("Salario bruto: R$ %.2f\n", salarioBruto);
    printf("Imposto: R$ %.2f\n", imposto);
    printf("Salario liquido: R$ %.2f\n", salarioLiquido);

    return 0;
}

