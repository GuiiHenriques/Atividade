#include <stdio.h>

int main() {
   float peso_saco, qtd_racao_gato;
   float total_racao, qtd_racao_cinco_dias;

   printf("Digite o peso do saco de racao (em quilos): ");
   scanf("%f", &peso_saco);

   printf("Digite a quantidade de racao fornecida para cada gato (em gramas): ");
   scanf("%f", &qtd_racao_gato);

   // Converter peso do saco para gramas
   total_racao = peso_saco * 1000;

   // Calcular quantidade de ra��o consumida por gato em cinco dias
   qtd_racao_cinco_dias = qtd_racao_gato * 2 * 5;

   // Calcular quantidade de ra��o restante ap�s cinco dias
   total_racao -= qtd_racao_cinco_dias;

   printf("A quantidade de racao restante no saco apos cinco dias sera de %.2f gramas.\n", total_racao);

   return 0;
}

