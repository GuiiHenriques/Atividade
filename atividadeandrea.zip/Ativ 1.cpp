#include <stdio.h>

int main() {
   float cota1, cota2, cota3, cota4, media;

   printf("Informe a cotacao do carro na concessionaria 1: ");
   scanf("%f", &cota1);

   printf("Informe a cotacao do carro na concessionaria 2: ");
   scanf("%f", &cota2);

   printf("Informe a cotacao do carro na concessionaria 3: ");
   scanf("%f", &cota3);

   printf("Informe a cotacao do carro na concessionaria 4: ");
   scanf("%f", &cota4);

   media = (cota1 + cota2 + cota3 + cota4) / 4;

   printf("A m�dia da cotacao do carro nas quatro concessionarias � de R$ %.2f", media);

   return 0;
}

