#include <stdio.h>
#include <math.h>

int main() {
   float raio, area;
   const float PI = 3.14159;

   printf("Informe o valor do raio do circulo: ");
   scanf("%f", &raio);

   area = PI * pow(raio, 2);

   printf("A area do circulo e de: %.2f\n", area);

   return 0;
}

