#include <stdio.h>
#include <math.h>

int main() {
   int a, b, c;
   double r, s, d, resultado;

   printf("Digite o valor de A: ");
   scanf("%d", &a);

   printf("Digite o valor de B: ");
   scanf("%d", &b);

   printf("Digite o valor de C: ");
   scanf("%d", &c);

   r = pow((a + b), 2.0);
   s = pow((b + c), 2.0);
   d = (r + s) / 2.0;

   resultado = pow(d, 1.0/3.0);

   printf("O resultado da expressao eh: %.2lf\n", resultado);

   return 0;
}

