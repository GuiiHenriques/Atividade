#include <stdio.h>

int main() {
   float salario, aumento, novoSalario;
   int percentual;

   printf("Informe o salario do funcionario: ");
   scanf("%f", &salario);

   printf("Informe o percentual de aumento: ");
   scanf("%d", &percentual);

   aumento = salario * percentual / 100;
   novoSalario = salario + aumento;

   printf("O valor do aumento e de R$ %.2f\n", aumento);
   printf("O novo salario e de R$ %.2f\n", novoSalario);

   return 0;
}

